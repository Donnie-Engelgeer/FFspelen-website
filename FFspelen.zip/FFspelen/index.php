<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php $pagename = basename($_SERVER['PHP_SELF']); ?>
    <?php include("SQL/connect.php"); ?>
    <?php include("navbar.php"); ?>
    <h1 class="welcome-message">Welcome to PowerCreep Games</h1>
    <div class="content">
        <?php
        $sql = "SELECT * FROM games";
        $query = $conn->prepare($sql);
        $query->execute();
        while ($game = $query->fetch()) {
            echo "<a href='gamepage.php?id= " . $game['id'] . "' class='game-box-a' >";
            echo "<div class='game-box'>";
            echo "<img src='" . $game['image'] . "' alt='" . $game['name'] . "' class='game-image'>";
            echo "<p><h2>" . $game['name'] . "</h2></p>";
            echo "</div>";
            echo "</a>";
        }
        ?>
    </div>
    <?php include("footer.php"); ?>
</body>

</html>