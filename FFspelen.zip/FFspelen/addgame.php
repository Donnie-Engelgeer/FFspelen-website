<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");

    if (isset($_SESSION['loggedin'])) {
        $sql = "SELECT * FROM accounts WHERE id = " . $_SESSION['loggedin'];
        $query = $conn->prepare($sql);
        $query->execute();
        while ($account = $query->fetch()) {
            if ($account["type"] == "admin") {
                if (isset($_POST['game_added'])) {

                    $name = $_POST['name'];
                    $description = $_POST['description'];
                    $image = $_POST['image'];
                    $url = $_POST['url'];

                    $sql = "INSERT INTO games (name, playcount, description, image, url) VALUES
                    ('$name', 0, '$description', '$image', '$url')";
                    $query = $conn->prepare($sql);
                    $query->execute();

                    header("Location: index.php");
                }
    ?>
                <div class="content">
                    <div class="addgame-form-box">
                        <h1>Nieuwe Game</h1>
                        <form action="addgame.php" method="post">
                            <div class="editboxes">
                                <div class="addgame-explanation">Download a game, place it in the folder called games. Then download an image and place it in images/game_images (or grab the url from the website you want to take the image from) and then proceed to fill in this form.</div>
                                <div class="name">
                                    <h2>Name</h2>
                                    <input type="text" name="name" required>
                                </div>
                                <div class="description">
                                    <h2>Description</h2>
                                    <textarea name="description" required></textarea>
                                </div>
                                <div class="image">
                                    <h2>Game Image Url/Path</h2>
                                    <input type="text" name="image" value="images/game_images" required>
                                </div>
                                <div class="url">
                                    <h2>Url/Path</h2>
                                    <input type="text" name="url" value="games/" required>
                                </div>
                                <button type="submit" name="game_added" value="nobody_will_read_this">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
    <?php
            }
        }
    }
    ?>
    <?php include("footer.php"); ?>
</body>

</html>