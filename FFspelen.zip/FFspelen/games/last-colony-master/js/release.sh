cat common.js aircraft.js game.js mouse.js singleplayer.js maps.js vehicles.js buildings.js terrain.js astar.js bullets.js fog.js sidebar.js sounds.js | uglifyjs -o game.min.js


