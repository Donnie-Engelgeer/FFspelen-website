export class View {
  constructor(game) {
    this.game = game;
  }
  initialize () {}
}
