/*global window:false*/
import 'normalize.css';

import * as game from './js/game';

const quantumGame = new game.Game();
quantumGame.htmlReady();
