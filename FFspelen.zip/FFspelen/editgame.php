<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");

    if (isset($_SESSION['loggedin'])) {
        $sql = "SELECT * FROM accounts WHERE id = " . $_SESSION['loggedin'];
        $query = $conn->prepare($sql);
        $query->execute();
        while ($account = $query->fetch()) {
            if ($account["type"] == "admin") {
                if (isset($_POST['game_edited'])) {

                    $name = $_POST['name'];
                    $description = $_POST['description'];
                    $image = $_POST['image'];
                    $url = $_POST['url'];

                    $sql = "UPDATE games SET name='$name', description='$description', image='$image', url='$url' WHERE id=" . $_POST['game_edited'];
                    $query = $conn->prepare($sql);
                    $query->execute();

                    header("Location: index.php");
                }
    ?>
                <div class="content">
                    <div class="editgame-form-box">
                        <h1>Edit Game</h1>
                        <?php
                        $sql = "SELECT * FROM games WHERE id = " . $_POST['editgame'];
                        $query = $conn->prepare($sql);
                        $query->execute();
                        while ($game = $query->fetch()) {
                            $name = $game['name'];
                            $description = $game['description'];
                            $image = $game['image'];
                            $url = $game['url'];
                        }
                        ?>
                        <form action="editgame.php" method="post">
                            <div class="editboxes">
                                <div class="name">
                                    <h2>Name</h2>
                                    <input type="text" name="name" value="<?php echo $name; ?>" required>
                                </div>
                                <div class="description">
                                    <h2>Description</h2>
                                    <textarea name="description" required><?php echo $description; ?></textarea>
                                </div>
                                <div class="image">
                                    <h2>Game Image Url/Path</h2>
                                    <input type="text" name="image" value="<?php echo $image; ?>" required>
                                </div>
                                <div class="url">
                                    <h2>Url/Path</h2>
                                    <input type="text" name="url" value="<?php echo $url; ?>" required>
                                </div>
                                <button type="submit" name="game_edited" value="<?php echo $_POST['editgame']; ?>">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
    <?php
            }
        }
    }
    ?>
    <?php include("footer.php"); ?>
</body>

</html>