<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");

    if (isset($_POST['contact-message-send'])) {
        $name = $_POST['contact-name'];
        $email = $_POST['contact-email'];
        $message = $_POST['contact-message'];

        $sql = "INSERT INTO contact_messages (name, email, message, status) VALUES
        ('$name', '$email', '$message', 'in progress')";
        $query = $conn->prepare($sql);
        $query->execute();
    ?>
        <div class="content">
            <div class="contact-form-box">
                <h1>Thanks for reaching out. We will reach back to you as soon as possible.</h1>
            </div>
        </div>
    <?php
    } else {
    ?>
        <div class="content">
            <div class="contact-form-box">
                <h1>contact</h1>
                <form action="contact.php" method="post">
                    <div class="editboxes">
                        <div class="name">
                            <h2>Name</h2>
                            <input type="text" name="contact-name" required>
                        </div>
                        <div class="email">
                            <h2>Email</h2>
                            <input type="email" name="contact-email" required>
                        </div>
                        <div class="message">
                            <h2>Message</h2>
                            <textarea name="contact-message" class="contact-message-field" required></textarea>
                        </div>
                        <button type="submit" name="contact-message-send" value="nobody_will_read_this">Send</button>
                    </div>
                </form>
            </div>
        </div>
    <?php
    }
    ?>
    <?php include("footer.php"); ?>
</body>

</html>