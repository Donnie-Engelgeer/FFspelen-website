DROP DATABASE IF EXISTS ffspelen;

CREATE DATABASE ffspelen;

USE ffspelen;

CREATE TABLE contact_messages (
    id int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
    name VARCHAR(500) NOT NULL,
    email VARCHAR(500) NOT NULL,
    message VARCHAR(500) NOT NULL,
    status ENUM('in progress', 'resolved') NOT NULL
);

INSERT INTO contact_messages (name, email, message, status) VALUES
("Test person", "Test@mail.com", "This is just a test message, please ignore!", "resolved"),
("Test person 2", "Test2@mail.com", "This is just another test message, please ignore!", "in progress");

CREATE TABLE accounts (
    id int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
    username VARCHAR(500) NOT NULL,
    password VARCHAR(500) NOT NULL,
    type ENUM('admin', 'user') NOT NULL
);

INSERT INTO accounts (username, password, type) VALUES
("Admin", "AdminPassword", "admin"),
("User", "UserPassword", "user");

CREATE TABLE games (
    id int(100) PRIMARY KEY AUTO_INCREMENT NOT NULL,
    name VARCHAR(500) NOT NULL,
    playcount int(100) NOT NULL,
    description TEXT NOT NULL,
    image VARCHAR(500) NOT NULL,
    url VARCHAR(500) NOT NULL
);

INSERT INTO games (name, playcount, description, image, url) VALUES
("Infine Jumper", 0, "Infine jumper is a platformer that infinitely goes on. See how many levels you can clear before you run out of lives.", "https://uploads.scratch.mit.edu/get_image/project/576104541_144x108.png", "https://scratch.mit.edu/projects/576104541/embed"),
("Picross", 0, "Picross is a picture logic puzzle in which you have to color or leave blank cells in a grid to reveal a hidden picture. The numbers at the side of the grid indicate how many unbroken lines of filled-in squares there are in any given row or column. You can use logic and deduction to figure out the correct sequence of cells to fill in or cross out", "https://uploads.scratch.mit.edu/get_image/project/432639952_144x108.png", "https://scratch.mit.edu/projects/432639952/embed"),
("Space Shooter", 0, "Shoot obstacles on the way to your goal. Collect powerups to increase your shooting speed and movement speed.", "https://uploads.scratch.mit.edu/get_image/project/226174490_144x108.png", "https://scratch.mit.edu/projects/226174490/embed"),
("Super Ballboy", 0, "Play through a bunch of difficult levels, fight bosses and reach the end.", "https://uploads.scratch.mit.edu/get_image/project/246261122_144x108.png", "https://scratch.mit.edu/projects/246261122/embed"),
("Clumsy Bird", 0, "Clumsy Bird is a clone of the “Flappy Bird” game and it makes use of the open source and lightweight HTML5 game engine MelonJS. The game works by you controlling a flying character and the mission is to successfully pass it from in-between the incoming walls without hitting them.", "https://raw.githubusercontent.com/ellisonleao/clumsy-bird/master/data/img/touch-icon-iphone-retina.png", "games/clumsy-bird-master"),
("Last Colony", 0, "Last Colony belongs to a real-time strategy (RTS) game genre which is a unique example of open source HTML5 and JavaScript games. It comes with single-player and multiplayer modes. In single-player campaign mode, the game has a scripted storyline where your task is to build the economy and defeat your enemies. The game has a variety of buildings, aircraft, and vehicles which creates excitement in its users. The interesting thing about this game is that its codebase is also written in HTML5, CSS3, and JavaScript.", "https://raw.githubusercontent.com/adityaravishankar/last-colony/master/images/splashscreen.png", "games/last-colony-master"),
("Quantum Game", 0, "Quantum Game is a simple and creative browser-based puzzle game that makes use of terminologies from quantum mechanics in the game. The game contains photon sources to emit photon particles, rocks that act as an obstacle, mirrors to deflect the photon particle, and a photon detector that receives the photon particle. The trick is to arrange the mirror in such a way that the photon particle emitted from the photon source should reach the photon detector evading the rocks. This game is developed using a simple HTML5 layout and JavaScript with CSS and sound plugins.", "https://raw.githubusercontent.com/stared/quantum-game/master/screenshot_qg_dev.png", "games/quantum-game-master"),
("Minecraft Classic", 0, "Minecraft Classic is the browser version of the world's most popular block-building sandbox game. It was released by its developer Mojang to celebrate the game's 10th anniversary. This version is a remake of the original and features original graphics that will make you feel nostalgic", "https://www.minecraft.net/content/dam/minecraft/news/minecraft-classic/HeaderCLASSIC.jpeg.transform/minecraft-image-large/image.jpeg", "https://classic.minecraft.net/"),
("Space Invaders", 0, "SpaceInvaders is an incredible space-themed shooting game developed using HTML5 and JavaScript code. This game is actually a remake of the space invader phaser game. The developer makes use of Require.js in order to make the code for this game more manageable and structured using JavaScript modules.", "https://www.edopedia.com/blog/wp-content/uploads/2018/04/SpaceInvaders_700.jpg?ezimgfmt=ng:webp/ngcb4", "games/SpaceInvaders-master"),
("Duck Hunt JS", 0, "Duck Hunt game is a very interesting and engaging game that everyone might have played during the reign of video games. In this game, we basically shoot the ducks which fly from the grass using a joystick but in this case, we use mouse clicks to knock down the flying ducks. This game is implemented using HTML5 and JavaScript. The developer has used PixiJS as a rendering engine and Green Sock Animations for animation purposes.", "https://raw.githubusercontent.com/MattSurabian/DuckHunt-JS/master/src/assets/images/dog/laugh/0.png", "games/DuckHunt-JS-master/dist"),
("Infinite Mario", 0, "This Infinite Mario game is a clone of the original Infinite Mario, coded in JavaScript for web browsers using HTML5 for UI/UX. This game features a good example of using Canvas and Audio elements. You will be able to learn a lot about Canvas and Audio elements going through the source code of this game available freely in GitHub.", "https://raw.githubusercontent.com/robertkleffner/mariohtml5/master/images/title.gif", "games/mariohtml5-master/main.html"),
("OPHog", 0, "OpHog is one of the most interesting and engaging tower defense games developed using HTML5 and JavaScript. The game lets you place defending units in order to defeat the enemy boss of each level while defending your portals. The developers have used HammerJS for touch gestures in the game and JQuery UI for the UI.", "https://i.imgur.com/jPyxd5B.png", "games/OPHog-master/src"),
("Canvas Tower Defense", 0, "a canvas/html5 javascript tower defense game", "https://www.edopedia.com/blog/wp-content/uploads/2018/04/Canvas-Tower-Defense-Game_700.jpg?ezimgfmt=ng:webp/ngcb4", "games/canvas_tower_defense-master"),
("Tower Building Game", 0, "Tower Building Game makes you feel joyful. Yes, that's true because the game is designed in such a way that we want to play it again and again.", "https://raw.githubusercontent.com/iamkun/tower_game/master/assets/favicon.png", "games/tower_game-master");