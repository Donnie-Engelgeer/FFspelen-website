<?php

error_reporting(E_ALL);

session_start();

$count = 1;

$servername = "localhost";
$username = "bit_academy";
$password = "bit_academy";
$db = "ffspelen";

$conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
if (!$conn) {
    die("Fatal Error: Connection Failed!");
}
?>