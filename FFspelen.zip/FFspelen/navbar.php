<nav>
    <?php
    if (isset($_POST['logout'])) {
        session_unset();
    }
    ?>
    <div class="navigation_div_start">
        <button id="logobutton" onClick="location.href='index.php'"><img src="images/logo.jpg" alt="powercreep-games-logo" class='home-button-logo'></button>
    </div>
    <div class="navigation_div_end">
        <?php
        if (isset($_SESSION['loggedin'])) {
            $sql = "SELECT * FROM accounts WHERE id = " . $_SESSION['loggedin'];
            $query = $conn->prepare($sql);
            $query->execute();
            while ($account = $query->fetch()) {
                echo '<div class="username">' . $account["username"] . '</div>';
                if ($account["type"] == "admin") {
                    if ($pagename == "addgame.php") {
                        echo '<form method="post" action="addgame.php"><button type="submit" id="addgame" name="addgame" style="filter: brightness(70%);"><h2 class="addgame-button-text">Add Game</h2></button></form>';
                    } else {
                        echo '<form method="post" action="addgame.php"><button type="submit" id="addgame" name="addgame"><h2 class="addgame-button-text">Add Game</h2></button></form>';
                    }
                    if ($pagename == "contact-messages.php") {
                        echo '<form method="post" action="contact-messages.php"><button type="submit" id="contact-messages" name="contact-messages" style="filter: brightness(70%);"><h2 class="contact-messages-button-text">Contact Messages</h2></button></form>';
                    } else {
                        echo '<form method="post" action="contact-messages.php"><button type="submit" id="contact-messages" name="contact-messages"><h2 class="contact-messages-button-text">Contact Messages</h2></button></form>';
                    }
                }
            }
            echo '<form method="post"><button type="submit" id="loginbutton" name="logout"><h2 class="login-button-text">Logout</h2></button></form>';
        } else {
            if ($pagename == "login.php") { ?>
                <button id="loginbutton" name="login" onClick="location.href='login.php'" style="filter: brightness(70%);">
                    <h2 class="login-button-text">Login</h2>
                </button>
            <?php } else { ?>
                <button id="loginbutton" name="login" onClick="location.href='login.php'">
                    <h2 class="login-button-text">Login</h2>
                </button>
            <?php } ?>

        <?php } ?>
    </div>
</nav>
<div class="nav-gradient"></div>