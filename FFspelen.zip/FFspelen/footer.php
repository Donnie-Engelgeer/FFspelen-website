<div class="footer-gradient"></div>
<footer>
    <div class='footer-box'>
        <div class="contact" id="footer_column">
            <h2>Contact us:</h2>
            <button id="footerbutton" onClick="location.href='contact.php'">Contact</button>
        </div>
        <div class="social-media-box" id="footer_column">
            <h2>Social Media:</h2>
            <button id="twitter" class="social-media-button" onClick="window.location.href='https://twitter.com';"><img src="images/social_media_images/twitter.png" alt="twitter" class='social-media-image'></button>
            <button id="twitter" class="social-media-button" onClick="window.location.href='https://facebook.com';"><img src="images/social_media_images/facebook.png" alt="twitter" class='social-media-image'></button>
        </div>
        <div class='creator-text' id="footer_column">
            <h2>Made by: <p>Donnie Engelgeer</p>
            </h2>
        </div>
    </div>
</footer>