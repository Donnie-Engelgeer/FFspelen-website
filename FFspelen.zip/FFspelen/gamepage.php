<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");
    $sql = "SELECT * FROM games WHERE id = " . $_GET['id'];
    $query = $conn->prepare($sql);
    $query->execute();
    if ($game = $query->fetch()) {
        $playcount = $game['playcount'] + 1;
    }
    $sql = "UPDATE games SET playcount='$playcount' WHERE id=" . $_GET['id'];
    $query = $conn->prepare($sql);
    $query->execute();
    ?>
    <div class="content">
        <div class="gamepage-content">
            <?php
            $sql = "SELECT * FROM games WHERE id = " . $_GET['id'];
            $query = $conn->prepare($sql);
            $query->execute();
            while ($game = $query->fetch()) {
                echo "<p><h1 class='gamepage-name'>" . $game['name'] . "</h1></p>";
                echo '<iframe src="' . $game['url'] . '" allowtransparency="true" max-width="1000px" width="90%" max-height="750px" height="750px" frameborder="0" scrolling="yes" allowfullscreen="true"></iframe>';
                echo "<div class='game-information'>";
                echo "<p><div class='playcount-text'><h2> Playcount: " . $game['playcount'] . "</h2></div></p>";
                echo "<p><div class='game-description'><h2>" . $game['description'] . "</h2></div></p>";
                echo "</div>";
            }
            ?>

            <?php
            if (isset($_SESSION['loggedin'])) {
                $sql = "SELECT * FROM accounts WHERE id = " . $_SESSION['loggedin'];
                $query = $conn->prepare($sql);
                $query->execute();
                while ($account = $query->fetch()) {
                    if ($account["type"] == "admin") {
                        echo '<form method="post" action="editgame.php"><button type="submit" id="editgame" name="editgame" value="' . $_GET['id'] . '"><h2 class="editgame-button-text">Edit Game</h2></button></form>';
                    }
                }
            }
            ?>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>

</html>