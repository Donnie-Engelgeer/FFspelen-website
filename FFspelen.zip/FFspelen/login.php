<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");
    ?>
    <div class="content">
        <div class="login-box">
            <h1>Login</h1>
            <?php
            unset($_SESSION['error']);

            if (isset($_POST['username']) && isset($_POST['password'])) {
                $stmt = $conn->prepare("SELECT id FROM accounts WHERE username = :username AND password = :password");
                $stmt->bindParam(':username', $_POST['username']);
                $stmt->bindParam(':password', $_POST['password']);
                $stmt->execute();

                $userid = $stmt->fetchColumn();
                $username = $_POST['username'];
                $password = $_POST['password'];

                echo $userid;

                if (is_numeric($userid)) {
                    $_SESSION['loggedin'] = $userid;
                    header("Location: index.php");
                    die();
                }

                $_SESSION['error'] = "<div class='invalid-login-text'>Invalid Username or Password</div>";
            }
            if (isset($_SESSION['error'])) {
                echo $_SESSION['error'];
            }
            ?>
            <form method="post">
                <p>
                <h2 class="login-titles">Username:</h2>
                <input type="text" name="username"></p>
                <p>
                <h2 class="login-titles">Password:</h2>
                <input type="password" name="password"></p>
                <p><button type="submit" name="submit" value="submitted" class="login-submit-button">Submit</button></p>
            </form>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>

</html>