<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PowerCreep Games</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
</head>

<body>
    <?php
    $pagename = basename($_SERVER['PHP_SELF']);
    include("SQL/connect.php");
    include("navbar.php");

    if (isset($_SESSION['loggedin'])) {
        $sql = "SELECT * FROM accounts WHERE id = " . $_SESSION['loggedin'];
        $query = $conn->prepare($sql);
        $query->execute();
        while ($account = $query->fetch()) {
            if ($account["type"] == "admin") {
                if (isset($_POST['unresolvebutton'])) {
                    $status = "in progress";
                    $sql = "UPDATE contact_messages SET status='in progress' WHERE id=" . $_POST['unresolvebutton'];
                    $query = $conn->prepare($sql);
                    $query->execute();
                }
                if (isset($_POST['resolvebutton'])) {
                    $status = "resolved";
                    $sql = "UPDATE contact_messages SET status='resolved' WHERE id=" . $_POST['resolvebutton'];
                    $query = $conn->prepare($sql);
                    $query->execute();
                }
    ?>
                <div class="content">
                    <div class="contact-messages-content">
                        <?php
                        $sql = "SELECT * FROM contact_messages ORDER BY id DESC";
                        $query = $conn->prepare($sql);
                        $query->execute();
                        while ($message = $query->fetch()) {
                            echo "<div class='message-box'>";
                            echo "<div class='contact-id-box'>";
                            echo "<h1> Id </h1>";
                            echo $message['id'];
                            echo "</div>";
                            echo "<div class='contact-name-box'>";
                            echo "<h1> Name </h1>";
                            echo $message['name'];
                            echo "</div>";
                            echo "<div class='contact-email-box'>";
                            echo "<h1> Email </h1>";
                            echo $message['email'];
                            echo "</div>";
                            echo "<div class='contact-message-box'>";
                            echo "<h1> Message </h1>";
                            echo $message['message'];
                            echo "</div>";
                            echo "<div class='contact-status-box'>";
                            echo "<h1> Status </h1>";
                            echo $message['status'];
                            echo "</div>";

                            if ($message['status'] == "resolved") {
                                echo '<form method="post"><button type="submit" id="unresolvebutton" name="unresolvebutton" value="' . $message['id'] . '"><h2> Unresolve </h2></button></form>';
                            } else {
                                echo '<form method="post"><button type="submit" id="resolvebutton" name="resolvebutton" value="' . $message['id'] . '"><h2> Resolve </h2></button></form>';
                            }

                            echo "</div>";
                        }
                        ?>
                    </div>
                </div>
    <?php
            }
        }
    }
    ?>
    <?php include("footer.php"); ?>
</body>

</html>